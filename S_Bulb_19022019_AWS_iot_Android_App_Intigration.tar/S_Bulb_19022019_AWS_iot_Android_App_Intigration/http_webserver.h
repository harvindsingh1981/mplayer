#ifndef __HTTP_WEBSERVER_H_
#define __HTTP_WEBSERVER_H_
void setup_http_request_handleres(void);
void monitor_http_server(void);
void handleon(void);
void handleoff(void);
void handlePing(void);
void handleint(void);
void handle_connectto(void);
void handle_savecred(void);
String connect_to_ap(String ssid, String password,String devicename);
void send_provisioning_status(String host_ip,bool conn_stat,String fail_reason,String ap_ssid,String ap_password,String device_name,String user_id);
//String urldecode(String str);
//String urlencode(String str);
//unsigned char h2int(char c);
#endif
