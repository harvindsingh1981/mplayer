#include "global.h"
#include "http_webserver.h"
#include "eeprom_functions.h"

ESP8266WebServer http_server(80);
extern bool led_status;
extern int led_intensity;
extern bool is_udp_connected;
extern char clientid_array[25];

void setup_http_request_handleres(void)
{
 http_server.on("/Ping",handlePing);//Web server for get and post request handling
 http_server.on("/on",handleon);
 http_server.on("/off",handleoff);
 http_server.on("/int",handleint);
 http_server.on("/CONNECT_TO",handle_connectto);
 http_server.on("/SAVE_CRED",handle_savecred); 
}

void monitor_http_server(void)
{
 http_server.handleClient();    //Handling of incoming requests 
}
//SSID=hs&Password=9990098297&Device_Name=Android_App&User_Id=SMAY_31979
void handle_savecred(void)
{
Serial.println("Credentials Save Request received");
String ssid=http_server.arg("SSID");
String password=http_server.arg("Password");
String device_name=http_server.arg("Device_Name");
String user_id=http_server.arg("User_Id");
char ssid_arr[35];
char password_arr[65];
char device_name_arr[35];
char user_id_arr[35];
ssid.toCharArray(ssid_arr,35);
password.toCharArray(password_arr,65);
device_name.toCharArray(device_name_arr,35);
user_id.toCharArray(user_id_arr,35);
Serial.println("Received Final User Credentials for Saving in EEPROM");
Serial.print("SSID : ");
Serial.println(ssid);  
Serial.print("PASSWORD : ");
Serial.println(password);  
Serial.print("Device Name : ");
Serial.println(device_name);  
Serial.print("User Id : ");
Serial.println(user_id);  
save_ssid_password(ssid_arr,password_arr);
write_device_name(device_name_arr);    
save_user_id(user_id_arr);
http_server.send(200,"text/plain","OK");
delay(2000);
ESP.restart();
//ESP.wdtDisable();
//ESP.wdtEnable(0);
//while (1) {};
}

void handle_connectto(void)
{
String ssid=http_server.arg("SSID");
String password=http_server.arg("Password");
String device_name=http_server.arg("Device_Name");
String host_ip=http_server.arg("IP");
String user_id=http_server.arg("User_Id");
String device_connection_status="";
bool conn_status=false;
Serial.println("Received User Credentials");
Serial.print("SSID : ");
Serial.println(ssid);  
Serial.print("PASSWORD : ");
Serial.println(password);  
Serial.print("Device Name : ");
Serial.println(device_name);  
Serial.print("IP Address : ");
Serial.println(host_ip);
Serial.print("User Id : ");
Serial.println(user_id);  
http_server.send(200,"text/plain","OK");
device_connection_status=connect_to_ap(ssid,password,device_name);
Serial.println(device_connection_status);
if(device_connection_status.equals("Provisioning Done"))
  {
    conn_status=true;
    send_provisioning_status(host_ip,conn_status,device_connection_status,ssid,password,device_name,user_id);
  }
else
  {
    conn_status=false;
    send_provisioning_status(host_ip,conn_status,device_connection_status,"","","","");
  }
}

void handleon(void)
{
//  digitalWrite(LED,1);
  analogWrite(LED,255);
  http_server.send(200,"text/plain","1");
  led_status=1;
}
void handleoff(void)
{
//  digitalWrite(LED,0);
  analogWrite(LED,0);
  http_server.send(200,"text/plain","0");
  led_status=0;  
}

void handlePing(void)
{
  String reply;
  char str[]="Pong";
  if(led_status)reply=String(str)+';'+String(wifi_station_get_hostname())+';'+'1'+';'+String(led_intensity)+';'+String(clientid_array);
  else reply=String(str)+';'+String(wifi_station_get_hostname())+';'+'0'+';'+String(led_intensity)+';'+String(clientid_array);
  Serial.println("Received Ping.......");
  http_server.send(200,"text/plain",reply);
  is_udp_connected=true;
}
void handleint(void)
{
  String message = "";
  int intensity;
  if (http_server.arg("Intensity")== ""){     //Parameter not found
  }
  else
  {
    message="ok";
    intensity=http_server.arg("Intensity").toInt();
    Serial.print("Setting light Intensity to ....");
    Serial.println(intensity);
    analogWrite(LED,intensity);
    led_intensity=intensity;
  }
  http_server.send(200, "text/plain", message); //Returns the HTTP response
}

void send_provisioning_status(String host_ip,bool conn_stat,String fail_reason,String ap_ssid,String ap_password,String device_name,String user_id)
{
  HTTPClient http;
  DynamicJsonBuffer jsonBuffer(1024);
  JsonObject& root = jsonBuffer.parseObject("{'requester':'Smayantr_Devices','conn_stat':false,'fail_reason':'','ap_ssid':'','ap_password':'','device_ip':'','device_name':'','user_id':''}");
  if (!root.success()) 
  {
    Serial.println("Failed to parse JSON Object");
    return;
  }
  if(conn_stat)root["conn_stat"]=true;
  else root["conn_stat"]=false;
  root["fail_reason"]=fail_reason;
  root["ap_ssid"]=ap_ssid;
  root["ap_password"]=ap_password;
  root["device_ip"]=WiFi.localIP().toString();
  root["device_name"]=device_name;
  root["user_id"]=user_id;
  String body;
  root.printTo(body);
  Serial.print("Request Body : ");
  Serial.println(body);
  http.begin(host_ip,1337);  //Specify request destination
  http.addHeader("Content-Type", "text/plain");  //Specify content-type header
  int httpCode = http.POST(body);   //Send the request
  if(httpCode>0)
  {
    Serial.printf("[HTTP] POST......code %d ",httpCode);
    if (httpCode == HTTP_CODE_OK)
    {
      String payload = http.getString();
      Serial.println(payload);
      http.end();  //Close connection
    }
  }
  else
  {
    Serial.printf("[HTTP] POST... failed, error: %s \n", http.errorToString(httpCode).c_str());
  }
}

String connect_to_ap(String ssid, String password,String devicename)
{
    String fail_reason;
    bool is_connected=false;
    char device_name_changed='n';
    bool ap_found=false;
    int wifi_status;
    int timeout;
    int ap_count;
    bool conn_status=false;
    char AP_SSID[60];
    char AP_PASSWORD[60];
    char device_name[60];
    ssid.toCharArray(AP_SSID,60);
    password.toCharArray(AP_PASSWORD,60);
    devicename.toCharArray(device_name,60);
    WiFi.mode(WIFI_AP_STA);
    Serial.println("Changing WiFi mode to STA + AP");
    if(WiFi.isConnected() && WiFi.localIP().toString()!="0.0.0.0")//check if wifi module is connected to AP
    {
        Serial.println("Module Connected with AP.....Disconnecting");
        WiFi.disconnect(1);
        while (WiFi.status() != WL_DISCONNECTED)
        {
          yield();
          Serial.print(".");//Wait for device disconnect from AP.
          delay(300);
        }
        Serial.println("Disconnected !!!");
        is_connected=false;//if not connected to requested AP then disconnect
    }
    else
    {
      Serial.println("Module Not Connected to WiFi");
      is_connected=false;
    }

    if(is_connected==false)
    {
        WiFi.mode(WIFI_AP);//changing mode only to AP because STA and AP uses same radio and while scanning AP's in WIFI_AP_STA mode, makes AP unstable and websocket server connection is intermitant.
        Serial.print("Scanning AP's........");
        ap_count=WiFi.scanNetworks();
        Serial.printf("%d AP's Found\n\r",ap_count);
        Serial.printf("Searching for \"%s\"\n\r",AP_SSID);
        for(int i=0;i<ap_count;i++)
        {
          if(WiFi.SSID(i).equals(String(AP_SSID)))
          {
            Serial.println("AP found !!!");
            ap_found=true;
            break;          
          }
        }
        if(!ap_found)
        {
          //Serial.println("AP Not Found");
          fail_reason="AP Not Found";
          ap_found=false;
        }
        else
        {
          WiFi.mode(WIFI_AP_STA);//enabling AP and STA mode for making connection only;
          Serial.print("Setting WiFi Device Name to ...."); 
          Serial.printf("%s\n\r",device_name);    
          if(wifi_station_set_hostname(device_name))Serial.println("DEVICE NAME SET.............SUCCESSFULLY");
          else Serial.println("DEVICE NAME SET.............FAIL");
          Serial.printf("Trying to connect with : SSID-%s , Password-%s\n\r",AP_SSID,AP_PASSWORD);
          WiFi.begin(AP_SSID,AP_PASSWORD);//Initiate New connection with requested AP
          wifi_status=WiFi.status();
          timeout=1000;//1000*35 = 35000ms or 35 Sec
          while(wifi_status==WL_DISCONNECTED && timeout>0)
          {
            wifi_status=WiFi.status();//wait for connection result
            Serial.print(".");
            delay(35);
            timeout --;
          }
          switch(wifi_status)
          {
            case WL_CONNECTED://connection successfull
              WiFi.setAutoConnect(true);//Configure module to automatically connect on power on to the last used access point
              WiFi.setAutoReconnect(true);//module will attempt to reconnect to an access point in case it is disconnected
              Serial.println("Connection Successfull !!!!");
              Serial.print("IP address: ");
              Serial.println(WiFi.localIP());
              conn_status=true;
            break;        
            case WL_NO_SSID_AVAIL://either SSID is wrong or not reachable
              Serial.println("Unable to connect");
              Serial.println("Reason : Either SSID is wrong or not reachable");
              conn_status=false;
              fail_reason="SSID wrong or unreachable";
            break;        
            case WL_CONNECT_FAILED://password is incorrect
              Serial.println("Unable to connect");
              Serial.println("Reason : Incorrect Password");
              conn_status=false;
              fail_reason="Incorrect Password";
            break;        
            case WL_IDLE_STATUS://wifi module in changing state
              Serial.println("Unable to connect");
              Serial.println("Reason : WiFi Module is busy");
              conn_status=false;
              fail_reason="WiFi Module Busy";
            break;        
            case WL_DISCONNECTED://module is not configured in station mode
              Serial.println("Unable to connect");
              Serial.println("Reason : Unknown");
              conn_status=false;
              fail_reason="Unknown";
            break;        
          }
        }
    }
    if(!conn_status)
    {
      //Serial.println(fail_reason);
      WiFi.mode(WIFI_AP);//if unable to connect with selected AP then there is no point to remain in STA mode because unconnected STA (Always searching for AP) makes websocket connection unstable.
      return(fail_reason);
    }
    else return("Provisioning Done");
    /************Command for saving credentials need to be sent seperatly from APP******************/
}

//String urldecode(String str)
//{
//    
//    String encodedString="";
//    char c;
//    char code0;
//    char code1;
//    for (int i =0; i < str.length(); i++){
//        c=str.charAt(i);
//      if (c == '+'){
//        encodedString+=' ';  
//      }else if (c == '%') {
//        i++;
//        code0=str.charAt(i);
//        i++;
//        code1=str.charAt(i);
//        c = (h2int(code0) << 4) | h2int(code1);
//        encodedString+=c;
//      } else{
//        
//        encodedString+=c;  
//      }
//      
//      yield();
//    }
//    
//   return encodedString;
//}
//
//String urlencode(String str)
//{
//    String encodedString="";
//    char c;
//    char code0;
//    char code1;
//    char code2;
//    for (int i =0; i < str.length(); i++){
//      c=str.charAt(i);
//      if (c == ' '){
//        encodedString+= '+';
//      } else if (isalnum(c)){
//        encodedString+=c;
//      } else{
//        code1=(c & 0xf)+'0';
//        if ((c & 0xf) >9){
//            code1=(c & 0xf) - 10 + 'A';
//        }
//        c=(c>>4)&0xf;
//        code0=c+'0';
//        if (c > 9){
//            code0=c - 10 + 'A';
//        }
//        code2='\0';
//        encodedString+='%';
//        encodedString+=code0;
//        encodedString+=code1;
//        //encodedString+=code2;
//      }
//      yield();
//    }
//    return encodedString;
//    
//}
//
//unsigned char h2int(char c)
//{
//    if (c >= '0' && c <='9'){
//        return((unsigned char)c - '0');
//    }
//    if (c >= 'a' && c <='f'){
//        return((unsigned char)c - 'a' + 10);
//    }
//    if (c >= 'A' && c <='F'){
//        return((unsigned char)c - 'A' + 10);
//    }
//    return(0);
//}

